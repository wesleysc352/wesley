ShapeChecker
============

To those who asked for it, here's the latest incarnation of the shapechecker.

It now supports automatic checking and fixing and a half-hearted 'debug' mode.

The debug mode will create a file c:\shapedebug.txt that contains description
of parts/points. Hopefully, some might find it useful.

The automatic mode will do as much as it can to check the shapefile. It will automatically
truncate a broken shp if need be and will add/remove/create dbf without prejudice.

There shouldn't be any instances where this is a problem. After all, if your shapefile
is broken or your dbf is missing then you won't be any worse off. Basically, all the
automatic setting does is push the buttons and answer 'yes' to the questions you'd
probably have answered 'yes' to yourself.

USE WITH CAUTION. 

Oh yeah... to use:

c:\> shapechk
	starts it the good old-fashioned interactive way. Still the best way.

c:\> shapechk /debug
	writes c:\shapedebug.txt containing a detailed breakdown of the shapefile
	this will take much longer to do. Not for everyday use.

c:\> shapechk c:\maps\postcode.shp /auto
	Automatically check the file specified. If you specify /auto and no filename
	you will be dumped into interactive mode. You may need to put filenames with
	spaces or weird characters in them in quotes to get it to work.
	eg. shapechk "c:\my maps\postcode file.shp" /auto

=====================================================================================
Please take care using this. It is the first release of the automatic version and as
such I may have screwed things up - though I can't think what.
=====================================================================================


Andrew Williamson
andrew_webby@bigfoot.com
http://www.geocities.com/SiliconValley/Haven/2295/